﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception1
{
    public class NaukriException:Exception
    {
        public NaukriException():base()
        {

        }
        public NaukriException(string message):base(message)
        {

        }
    }
}
